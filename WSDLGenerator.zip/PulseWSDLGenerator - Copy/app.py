from flask import Flask, render_template, request, send_file
from jinja2 import Template
import json
import os

app = Flask(__name__)

# Load WSDL template
with open('wsdl_template.xml') as file:
    wsdl_template = file.read()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Extract information from the form
        service_name = request.form.get('service_name')
        operation_name = request.form.get('operation_name')
        url = request.form.get('url')
        method = request.form.get('method')
        headers = request.form.get('headers')
        parameters = request.form.get('parameters')
        body = request.form.get('body') if method not in ['GET', 'DELETE'] else ''
        response_body = request.form.get('response_body')
        mandatory_fields_input = request.form.get('mandatory_fields')  # Text input with comma-separated fields
        mandatory_fields = [field.strip() for field in mandatory_fields_input.split(',')] if mandatory_fields_input else []

        print("Mandatory Fields Received:", mandatory_fields)  # Debugging print statement

        # Parse the body to get fields if it's a valid JSON
        try:
            body_fields = json.loads(body)
        except json.JSONDecodeError:
            body_fields = {}

        # Parse the response body to get fields if it's a valid JSON
        try:
            response_fields = json.loads(response_body)
        except json.JSONDecodeError:
            response_fields = {}

        # Convert JSON fields to WSDL types with minOccurs logic
        def json_to_wsdl_types(fields, prefix=''):
            elements = []
            if isinstance(fields, dict):
                for key, value in fields.items():
                    full_key = f"{prefix}{key}" if prefix else key
                    min_occurs = '1' if full_key in mandatory_fields else '0'

                    if isinstance(value, dict):
                        elements.append({
                            'name': key,
                            'type': 'complexType',
                            'fields': json_to_wsdl_types(value, prefix=f"{full_key}."),
                            'minOccurs': min_occurs
                        })
                    elif isinstance(value, list):
                        if value and isinstance(value[0], dict):  # List of dictionaries (complexType)
                            elements.append({
                                'name': key,
                                'type': 'complexType',
                                'fields': json_to_wsdl_types(value[0], prefix=f"{full_key}."),
                                'minOccurs': min_occurs,
                                'maxOccurs': 'unbounded'
                            })
                        else:  # List of simple types
                            elements.append({
                                'name': key,
                                'type': 'xsd:string',
                                'minOccurs': min_occurs,
                                'maxOccurs': 'unbounded'
                            })
                    else:
                        elements.append({
                            'name': key,
                            'type': 'xsd:string',
                            'minOccurs': min_occurs
                        })
            return elements

        request_elements = json_to_wsdl_types(body_fields)
        response_elements = json_to_wsdl_types(response_fields)

        # Prepare the data to be passed to the template
        data = {
            'service_name': service_name,
            'operation_name': operation_name,
            'url': url,
            'method': method,
            'headers': headers,
            'parameters': parameters,
            'request_elements': request_elements,
            'response_elements': response_elements
        }

        # Render the WSDL using the template
        template = Template(wsdl_template)
        wsdl_content = template.render(data)

        # Save the WSDL to a file
        wsdl_filename = f"{service_name}.wsdl"
        with open(wsdl_filename, 'w') as f:
            f.write(wsdl_content)

        # Provide the file for download
        return send_file(wsdl_filename, as_attachment=True)

    return render_template('website.html')

if __name__ == '__main__':
    app.run(debug=True)
